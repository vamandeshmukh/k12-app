
const actionTypes = (payload) => {
    return {type: 'ADD_POST', payload};
}
export default actionTypes;

export const ADD_POST = 'ADD_POST';
