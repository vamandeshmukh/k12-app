
const addPost = (payload) => {
    return {type: 'ADD_POST', payload};
}
export default addPost;