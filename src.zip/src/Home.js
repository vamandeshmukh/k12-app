import logo from './logo.svg';
import './App.css';

function Home() {
    return (
        <div >
            <p className="display-4">This is Home page.</p>
            <p className="k12">This is the home paragraph.</p>
        </div>

    );
}

export default Home;
