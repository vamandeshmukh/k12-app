import React from 'react';
import './App.css';

function PageNotFound() {
    return (
        <div >
            <p className="display-4">PageNotFound</p>
            <p className="k12">PageNotFound</p>
        </div>

    );
}

export default PageNotFound;
