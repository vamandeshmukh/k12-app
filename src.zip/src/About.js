import logo from './logo.svg';
import './App.css';
import React from 'react';

class About extends React.Component {

    render() {
        return (
            <div className="App">
                <h1 className="display-4">this is About of class component</h1>
                <p className='k12'>this is my About of class component paragrph</p>
            </div>
        )
    }
}
export default About;
