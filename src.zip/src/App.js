import './App.css';
import Routes from './Routes';
import DataMapper from './reduxStore/DataMapper';
function App() {
  return (
    <div className="App">
      <link rel="stylesheet"
        href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" />
      <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
      <p className="display-4">K12 App Header</p>
      {/* <Header /> */}
      <Routes />
      <DataMapper />
      {/* <Footer /> */}
    </div>
  );
}
export default App;
