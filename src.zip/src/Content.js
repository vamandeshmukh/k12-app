import React from 'react';

const content = () => {
    return (  
    <p>The time now is { Date.now()} .</p> 
    );
}

export default content;
